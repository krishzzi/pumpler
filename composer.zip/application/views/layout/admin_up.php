<?php
require __DIR__.'/admin/header.php';
require __DIR__.'/admin/navbar.php';

require __DIR__.'/admin/sidebar.php';
?>
<div class="content-wrapper">
