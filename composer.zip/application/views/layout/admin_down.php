</div>
<?php

require __DIR__.'/admin/page_footer.php';
require __DIR__.'/admin/controlbar.php';
require __DIR__.'/admin/footer.php';

?>