<?php

class CustomerApi extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('userModel');
	}

	public function index ()
	{
		$data = $this->userModel->select()->where('role','customer')->where('is_admin',false)->all();
		if($data)
		{
			renderJson($data);
		}else{
			renderJsonError('Wrong Credential');
		}


	}


	public function login()
	{

		$method = $_SERVER['REQUEST_METHOD'];

		if($method != 'POST'){
			renderJsonError('Bad request',400);
		} else {
			if($this->userModel->validClient() == true)
			{
				$mobile = $_REQUEST['mobile'];
				$password = $_REQUEST['password'];
				$this->userModel->login($mobile,$password);
			}
		}

	}


	public function getDetails()
	{

		dd($_REQUEST);

		$this->userModel->select()->from()->where('id',$_REQUEST['id'])->count();


	}



}
